import React from 'react'

function Mteeinspage() {
  return (
    <div>Mteeinspage</div>
  )
}

export default Mteeinspage