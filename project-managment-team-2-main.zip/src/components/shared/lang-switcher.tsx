import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useTranslation } from "react-i18next";
import { useEffect } from "react";

export default function LangSwitcher() {
  const { i18n } = useTranslation();

  const handleLanguageChange = (value: string) => {
    i18n.changeLanguage(value);
    document.documentElement.dir = value === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = value;
  };

  // Sync document direction on mount/language change
  useEffect(() => {
    document.documentElement.dir = i18n.language === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = i18n.language;
  }, [i18n.language]);

  return (
    <Select value={i18n.language} onValueChange={handleLanguageChange}>
      <SelectTrigger className="max-w-48 p-6 px-4 rounded-2xl cursor-pointer text-md! font-semibold! data-[state=open]:text-md! data-[state=open]:font-semibold! data-[placeholder]:text-md! data-[placeholder]:font-semibold! [&_svg]:text-mainText! [&_svg]:w-4!">
        <SelectValue placeholder="Language" />
      </SelectTrigger>
      <SelectContent className="relative z-150">
        <SelectGroup>
          <SelectItem value="en" className="capitalize cursor-pointer">
            English
          </SelectItem>
          <SelectItem value="ar" className="capitalize cursor-pointer">
            Arabic
          </SelectItem>
        </SelectGroup>
      </SelectContent>
    </Select>
  );
}
