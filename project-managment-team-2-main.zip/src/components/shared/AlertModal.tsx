"use client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Toaster } from "@/components/ui/sonner";
import type { ReactNode } from "react";
export default function AlertModal({children}: {children: ReactNode}) {
        return (
            <html lang="en">
            <body>
                {children}
                <Toaster />
            </body>
            </html>
        )
    }