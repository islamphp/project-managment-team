import React from "react";

  export const ALLprojectapage = () => {
  return <div>Projects</div>;
};
export default ALLprojectapage;