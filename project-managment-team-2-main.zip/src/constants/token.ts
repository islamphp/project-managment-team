export const TOKEN =
"24|stZVgDp4Thvdg0zkgVheDo1svNoSSXVT8auHLJ9576afcf32";

export const TOKE =
"35|Lt4LwIxGYoTRQQ645MJZL6ihIx8bzfpJGiCM1ZxH197e7b40";

export const tokenOld =
"85|kmfdfJKEZuwS4QtO3oPfil0cAmjmfRuTQlWrw7TN74aa6e9d";

/*
Old Endpoint:
GET {{url}}/dashboard/recent-files

New Endpoint:
GET {{url}}/dashboard/project-overview?project_id=1
*/
export const token = "9|scOVS9YH3sMpAY9zqhQuWrZGSaQYUWgZYeXAH82Of2b549b8";
