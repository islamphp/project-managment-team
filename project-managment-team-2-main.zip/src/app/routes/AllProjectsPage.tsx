import {
  Search,
  BriefcaseBusiness,
  File,
  Users,
  ChevronDown,
} from "lucide-react";
import { useState, useEffect } from "react";
import axios from "axios";

import Dropdown from "@/features/AddMettingPage/components/Dropdown";
import NewProjectModal from "@/features/AllProjectsPage/NewProjectModal";
import Projectbref from "@/features/profilePage/components/Projectbref";
import Overview from "@/features/AllProjectsPage/Overview";
import Tasks from "@/features/AllProjectsPage/Tasks";
import Teams from "@/features/AllProjectsPage/teams/Teams";
import FilesTab from "@/features/AllProjectsPage/FilesTab";
import AddProjectButton from "@/features/AllProjectsPage/AddProjectButton";

function AllProjectsPage() {
  let [isOpen, setIsOpen] = useState(false);
  let [is2Open, setIs2Open] = useState(false);
  // Selected Projects For Select
  let [selectedProjectSelect, setSelectedProjectSelect] =
    useState("All Projects");
  let [sortBy, setSortBy] = useState("newest");
  let [searchQuery, setSearchQuery] = useState("");
  let [isModalOpen, setIsModalOpen] = useState(false);
  let [selectedPage, setSelectedPage] = useState("all projects");
  let [selectedProject, setSelectedProject] = useState<any>(null);

  // API Data
  let [projectsData, setProjects] = useState<any[]>([]);
  let [loading, setLoading] = useState(true);
  let [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setLoading(true);
        const response = await axios.get(
          "https://collabspace-team-one.newcinderella.online/api/projects",
          {
            headers: {
              Authorization: `Bearer 8|3RvEjkCc9qKsuZcwLkjrrMrdeuSGHklTIO4Gm6xZb1247378`,
            },
          },
        );

        if (response.data) {
          const fetchedData = response.data.data;
          setProjects(Array.isArray(fetchedData) ? fetchedData : []);
        }
        setError(null);
      } catch (error) {
        console.error("Error fetching projects:", error);
        setError("فشل في تحميل المشاريع من السيرفر.");
      } finally {
        setLoading(false);
      }
    };
    fetchProjects();
  }, []);

  // FIlter Projects By Search

  let searchProjects = projectsData.filter((project) => {
    return project.name.toLowerCase().includes(searchQuery.toLowerCase());
  });

  // Filter Projects By name

  let filteredProjects = searchProjects.filter((project) => {
    if (selectedProjectSelect === "All Projects") return true;
    return selectedProjectSelect === project.name;
  });

  // Filter Projects by Date
  let sortedAndFilteredProjects = filteredProjects.slice().sort((a, b) => {
    const dateA = a.start_date ? new Date(a.start_date) : new Date(0);
    const dateB = b.start_date ? new Date(b.start_date) : new Date(0);

    if (sortBy === "newest") {
      return dateB.getTime() - dateA.getTime(); // الأحدث أولاً
    } else {
      return dateA.getTime() - dateB.getTime(); // الأقدم أولاً
    }
  });

  const statusColors: Record<string, string> = {
    pending: "text-yellow-600",
    in_progress: "text-blue-600",
    completed: "text-green-600",
  };

  const priorityColors: Record<string, string> = {
    low: "text-green-600",
    medium: "text-yellow-600",
    high: "text-red-600",
  };
  return (
    <>
      <div className="">
        <div className="flex flex-col">
          {selectedPage === "all projects" && (
            <>
              <div className="flex justify-between items-center">
                <h1 className="text-black text-xl font-medium">All Projects</h1>
                <AddProjectButton setIsModalOpen={setIsModalOpen} />
                {/* Add Project Modal */}
                {isModalOpen && (
                  <NewProjectModal
                    setIsModalOpen={setIsModalOpen}
                    setProjects={setProjects}
                  />
                )}
              </div>
              <div className="flex justify-between mt-5 items-center">
                {/* Search */}
                <div className="relative text-black">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2  w-4" />
                  <input
                    type="text"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-white h-7 w-full pl-10 pr-4 py-2 border border-gray-300 text-sm rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-400 placeholder-black"
                  />
                </div>
                {/* Select */}
                <div className="flex gap-2 relative">
                  <div
                    className="flex items-center gap-1 text-black border border-black rounded-xl px-3 py-2 cursor-pointer"
                    onClick={() => setIsOpen((prev) => !prev)}
                  >
                    {selectedProjectSelect}
                    <ChevronDown size={20} strokeWidth={2} />
                  </div>
                  {/* Second Select */}
                  <div
                    className="flex items-center gap-1 text-black border border-black rounded-xl px-3 py-2 cursor-pointer"
                    onClick={() => {
                      setIs2Open((prev) => !prev);
                    }}
                  >
                    {sortBy}
                    <ChevronDown size={20} strokeWidth={2} />
                  </div>
                  {/* Dropdown */}
                  {isOpen && (
                    <Dropdown
                      projectsData={[
                        { id: "allprojects", name: "All Projects" },
                        ...projectsData,
                      ]}
                      setSelectedProjectSelect={setSelectedProjectSelect}
                      setIsOpen={setIsOpen}
                    />
                  )}
                  {/* Second Dropdown */}
                  {is2Open && (
                    <Dropdown
                      projectsData={[
                        { id: "newest", name: "newest" },
                        { id: "oldest", name: "oldest" },
                      ]}
                      setSelectedProjectSelect={setSortBy}
                      setIsOpen={setIs2Open}
                    />
                  )}
                </div>
              </div>
              {/* Tabel */}
              <table className="mt-5 text-left py-5 text-sm">
                <thead>
                  <tr className="text-black font-extralight border-b-2">
                    <th className="py-3">Project Name</th>
                    <th>Start Date</th>
                    <th>Deadline</th>
                    <th>Status</th>
                    <th>Files</th>
                    <th>Teams</th>
                    <th>Priority</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedAndFilteredProjects.map((project) => (
                    <tr
                      key={project.id}
                      onClick={() => {
                        setSelectedPage("overview");
                        setSelectedProject(project);
                      }}
                      className="bg-white border-t-10 border-gray-100 cursor-pointer hover:bg-gray-200"
                    >
                      <td className="p-3 flex gap-1 items-center text-black">
                        <BriefcaseBusiness />
                        {project.name}
                      </td>
                      <td>{project.start_date}</td>
                      <td>{project.deadline || "No Deadline"}</td>
                      <td className={`${statusColors[project.status]}`}>
                        {project.status}
                      </td>
                      <td>
                        <div className="flex items-center">
                          <File className="text-yellow-300 text-xs" />
                          {project.filesCount || "none"} Files
                        </div>
                      </td>
                      <td>
                        <div className="flex items-center">
                          <Users size={20} strokeWidth={2} />
                          {project.team?.join(", ") || "No Team"}
                        </div>
                      </td>
                      <td className={`${priorityColors[project.priority]}`}>
                        {project.priority}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}

          {/* Open pages */}
          {selectedPage !== "all projects" && (
            <>
              <Projectbref
                project={selectedProject}
                setSelectedPage={setSelectedPage}
                selectedPage={selectedPage}
              />
              {selectedPage === "overview" && <Overview project={selectedProject} />}
              {selectedPage === "tasks" && <Tasks projectId={selectedProject.id} />}
              {selectedPage === "teams" && <Teams projectId={selectedProject.id} />}
              {selectedPage === "files" && <FilesTab project={selectedProject} />}
            </>
          )}
        </div>
      </div>
    </>
  );
}

export default AllProjectsPage;
