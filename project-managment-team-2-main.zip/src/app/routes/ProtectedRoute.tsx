import { getToken } from "@/cookies/authServices";
import { Navigate ,Outlet} from "react-router-dom";
import Navbar from "@/components/layout/Navbar";

const ProtectedRoute=()=>{
    const token=getToken();
    
    return token && token!=="undefined"? (
      <div className="min-h-screen bg-[#f5f7fa] pb-10">
        <Navbar />
        <Outlet/>
      </div>
    ) : (
      <Navigate to="/signin" replace/>
    );
}

export default ProtectedRoute;