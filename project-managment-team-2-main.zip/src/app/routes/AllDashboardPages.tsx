import Login from "@/features/Authentication/components/Login";
import Signup from "@/features/Authentication/components/Signup";
import ForgetPass from "@/features/Authentication/components/ForgetPass";
import ProfilePage from "@/features/profilePage/components/profilePage";
import ProfilePageTasks from "@/features/profilePage/components/ProfilePageTasks";
import ProfilePageAbout from "@/features/profilePage/components/ProfilePageAbout";
import ProfilePageFiles from "@/features/profilePage/components/ProfilePageFiles";
import AddMeetingCalendarPage from "@/features/AddMettingPage/components/calendar"
import VerifyOtp from "@/features/Authentication/components/VerifyOTP"
import ResetPassword from "@/features/Authentication/components/ResetPassword";
import ErrorPage from "./404Page";
import Calendar from "@/features/AddMettingPage/components/calendar";
import DashboardCards from "@/features/tasks/components/dashboard/DashboardCards";
import Dashboardstats from "@/features/tasks/components/dashboard/Dashboardstats";
import Dashboardbutton from "@/features/tasks/components/dashboard/Dashboardbutton";
// import AllProjects from "./AllProjectsPage";

export const LoginPage=()=><Login/>
export const SignupPage=()=><Signup/>
export const VerifyOTP = () => <VerifyOtp />;
export const ForgetPassPage=()=><ForgetPass/>
export const DashboardPage=() => (
  <div className="flex flex-col gap-6 w-full mt-2">
    <DashboardCards />
    <Dashboardstats />
    <Dashboardbutton />
  </div>
);
export const ProfilePageData = () => <ProfilePage />
export const ProfileTasksPage=()=><ProfilePageTasks/>
export const ProfileFilesPage=()=><ProfilePageFiles/>
export const ProfileAboutPage=()=><ProfilePageAbout/>
export const ResetPasswordPage=()=><ResetPassword/>
export const Error = ()=> <ErrorPage/>
export const CalendarPage=()=><Calendar/>
export const ChatsPage = () => (
  <div className="flex flex-col items-center justify-center min-h-[60vh] bg-white rounded-3xl p-10 shadow-sm m-4 text-center">
    <span className="text-5xl mb-4">💬</span>
    <h2 className="text-2xl font-bold text-gray-800 mb-2">Chats</h2>
    <p className="text-gray-500 max-w-sm">This feature is currently under development. Stay tuned for real-time collaboration!</p>
  </div>
);
