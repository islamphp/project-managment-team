const ErrorPage=()=>{
    return (
      <section className="mainContainer flex justify-center items-center min-h-[calc(100vh-82px)]">
        <h1 className="text-6xl font-semibold flex items-center justify-center">404 Page Not Found</h1>
      </section>
    );
}
export default ErrorPage;