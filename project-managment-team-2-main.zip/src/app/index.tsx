import {
  ForgetPassPage,
  LoginPage,
  SignupPage,
  VerifyOTP,
  ResetPasswordPage,
} from "./routes/AllDashboardPages";
import {
  ProfilePageData,
  ProfileTasksPage,
  ProfileFilesPage,
  ProfileAboutPage,
  Error,
  DashboardPage,
  CalendarPage,
  ChatsPage,
} from "./routes/AllDashboardPages";
import TasksPage from "./routes/TasksPage";
import AllProjectsPage from "./routes/AllProjectsPage";
import ReportsPage from "./routes/ReportsPage";
import App from "@/App";
import ProtectedRoute from "./routes/ProtectedRoute";
import { createBrowserRouter } from "react-router-dom";

export const Router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "signin",
        element: <LoginPage />,
      },
      {
        path: "signup",
        element: <SignupPage />,
      },
      {
        path: "forgetPass",
        element: <ForgetPassPage />,
      },
      {
        path: "verifyOtp",
        element: <VerifyOTP />,
      },
      {
        path: "resetPass",
        element: <ResetPasswordPage />,
      },
      {
        element: <ProtectedRoute />,
        children: [
          {
            index: true,
            element: <DashboardPage />,
          },
          {
            path: "dashboard",
            element: <DashboardPage />,
          },
          {
            path: "projects",
            element: <AllProjectsPage />,
          },
          {
            path: "calendar",
            element: <CalendarPage />,
          },
          {
            path: "meetings",
            element: <CalendarPage />,
          },
          {
            path: "tasks",
            element: <TasksPage />,
          },
          {
            path: "reports",
            element: <ReportsPage />,
          },
          {
            path: "chats",
            element: <ChatsPage />,
          },
          {
            path: "profile",
            element: <ProfilePageData />,
            children: [
              {
                index: true,
                element: <ProfileAboutPage />,
              },
              {
                path: "overview",
                element: <ProfileAboutPage />,
              },
              {
                path: "tasks",
                element: <ProfileTasksPage />,
              },
              {
                path: "files",
                element: <ProfileFilesPage />,
              },
              {
                path: "*",
                element: <Error />,
              },
            ],
          },
          {
            path: "*",
            element: <Error />,
          },
        ],
      },
    ],
  },
]);
