const ProfileUpdatePage = () => {
  return
   <>
  </>;
};

export default ProfileUpdatePage;
