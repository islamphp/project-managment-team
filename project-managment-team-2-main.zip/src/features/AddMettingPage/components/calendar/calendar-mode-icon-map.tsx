// src/calendar/calendar-mode-icon-map.tsx

import React from "react";
import { type Mode } from "./calendar-types";
import { Calendar, CalendarDays, CalendarRange } from "lucide-react";
export const modeIconMap: Record<Mode, React.ReactElement> = {
  day: <Calendar />,
  week: <CalendarDays />,
  month: <CalendarRange />,
};
