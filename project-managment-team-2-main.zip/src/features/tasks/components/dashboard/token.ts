export const TOKEN = 
{
    "success": true,
    "message": "Registration successful. Please verify your email.",
    "data": {
        "user": {
            "name": "WafaaMohammed",
            "email": "wafaa123@test.com",
            "updated_at": "2026-06-29T20:09:22.000000Z",
            "created_at": "2026-06-29T20:09:22.000000Z",
            "id": 13
        }
    },
    "paginate": null
}